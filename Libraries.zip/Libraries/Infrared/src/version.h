// This file was automatically generated from library.properties; do not edit.
#pragma once
/**
 * Version of the current library.
 * Taken from the version in library.properties.
 */
#define VERSION "1.2.0"
